# Student-Registration-Crud-Operation
This is a Student Registration Crud Operation in php with MySQL Database

First of all you need to create a data base name "user"
and create a table "card_activation"

Import database from our given .sql file

and dont forgot to create a image folder in your directory "upload_images"
